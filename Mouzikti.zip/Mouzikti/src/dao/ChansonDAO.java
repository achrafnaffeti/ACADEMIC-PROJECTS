/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.Chanson;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import technique.connection;

/**
 *
 * @author dhia
 */
public class ChansonDAO {
    
     private static ChansonDAO instanceDAOsong;
    private Statement stmt;
    List<Chanson> l=new ArrayList<Chanson>();
    
    private ChansonDAO() throws ClassNotFoundException, SQLException{
        stmt=connection.getInstance().getCn().createStatement();
               
    }
    public static ChansonDAO getInstance() throws ClassNotFoundException, SQLException{
        if(instanceDAOsong==null)
        instanceDAOsong=new ChansonDAO();
        return instanceDAOsong;
        
    }
    
    public List<Chanson> getSongs() throws SQLException{
        ResultSet rs=stmt.executeQuery("select * from chanson");
        
        while(rs.next())
        {Chanson c=new Chanson
                (rs.getInt(1), rs.getString(2), rs.getString(3),rs.getString(4), rs.getString(5), rs.getInt(6),rs.getString(7));
        l.add(c);
            
        }
        return l;
    }
    public Chanson getSong(String s) throws SQLException{
        ResultSet rs=stmt.executeQuery("select * from chanson where titre ='"+s+"'");
        
       rs.next();
        
        Chanson c=new Chanson
               (rs.getString(2), rs.getString(3),rs.getString(4), rs.getString(5),rs.getString(7));
        
        return c;
    }

    public boolean ajoutSong(Chanson c) {
        try {
            stmt.executeUpdate("insert into chanson "
                    + "values('"+
                    0+"','"+
                    c.getTitre()+"','"+
                    c.getAlbum()+"','"+
                    c.getGenre()+"','"+
                    c.getArtiste()+"','"+
                    0+"','"+
                    c.getUrl()+"')");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return false;
        }
        return true;
    }

   

    public List<Chanson> getSongsR(String s) throws SQLException {
         ResultSet rs=stmt.executeQuery("select * from chanson where titre like'%"+s+"%' or artiste like'%"+s+"%'");
        
        while(rs.next())
        {Chanson c=new Chanson
                (rs.getInt(1), rs.getString(2), rs.getString(3),rs.getString(4), rs.getString(5), rs.getInt(6),rs.getString(7));
        l.add(c);
            
        }
        return l;
    }

   
    
    
}
