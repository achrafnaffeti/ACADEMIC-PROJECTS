/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import java.sql.*;
import entity.Utilisateur;
import technique.connection;
import java.sql.SQLException;
import java.util.*;
/**
 *
 * @author ibtihel
 */
public class UtilisateurDAO {
    private static UtilisateurDAO instanceDAOUser;
    private Statement stmt;
    List<Utilisateur> l=new ArrayList<Utilisateur>();
    
    private UtilisateurDAO() throws ClassNotFoundException, SQLException{
        stmt=connection.getInstance().getCn().createStatement();
               
    }
    public static UtilisateurDAO getInstance() throws ClassNotFoundException, SQLException{
        if(instanceDAOUser==null)
        instanceDAOUser=new UtilisateurDAO();
        return instanceDAOUser;
        
    }
    
    public List<Utilisateur> getUsers() throws SQLException{
        ResultSet rs=stmt.executeQuery("select * from utilisateur");
        
        while(rs.next())
        {Utilisateur u=new Utilisateur
                (rs.getInt(1), rs.getString(2), rs.getString(3),rs.getString(4), rs.getInt(5), rs.getString(6),rs.getString(7), rs.getString(8), rs.getString(9));
        l.add(u);
            
        }
        return l;
    }
    public Utilisateur getUser(int id) throws SQLException{
        ResultSet rs=stmt.executeQuery("select * from utilisateur where id ='"+id+"'");
        
       rs.next();
        
        Utilisateur u=new Utilisateur
                (rs.getInt(1), rs.getString(2), rs.getString(3),rs.getString(4), rs.getInt(5), rs.getString(6),rs.getString(7), rs.getString(8), rs.getString(9));
        
        return u;
    }

    public boolean ajouterMembre(Utilisateur u) {
        try {
            stmt.executeUpdate("insert into utilisateur "
                    + "values('"+
                    u.getId()+"','"+
                    u.getNom()+"','"+
                    u.getPrenom()+"','"+
                    u.getMail()+"','"+
                    u.getTel()+"','"+
                    u.getLogin()+"','"+
                    u.getPassword()+"','"+
                    u.getType()+"','"+ 
                    u.getActivation()+"')");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return false;
        }
        return true;
    }

    public boolean modifierMembre(int id, Utilisateur u) {
        try {
            stmt.executeUpdate("update utilisateur   set "
                    + "id='"+u.getId()
                    + "',nom='"+u.getNom()
                    + "',prenom='"+u.getPrenom()
                    + "',mail='"+u.getMail()
                    + "',tel='"+u.getTel()
                    + "',login='"+u.getLogin()
                    + "',password='"+u.getPassword()
                    + "',type='"+u.getType()
                    + "',activation='"+u.getActivation()
                    + "' where id = '"+id+"'");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return false;
        }
        return true;
    }

    public boolean suppMembre(int id) {
 try {
            stmt.executeUpdate("delete from utilisateur where id='"+id+"'");
 
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return false;
        }
        return true;
   
    }

    public List<Utilisateur> getUsersR(String s) throws SQLException {
         ResultSet rs=stmt.executeQuery("select * from utilisateur where nom like'%"+s+"%' or id like'%"+s+"%' or prenom like'%"+s+"%' or mail like'%"+s+"%' or tel like'%"+s+"%' or login like'%"+s+"%' or password like'%"+s+"%' or type like'%"+s+"%' or activation like'"+s+"%' ");
        
        while(rs.next())
        {Utilisateur u=new Utilisateur
                (rs.getInt(1), rs.getString(2), rs.getString(3),rs.getString(4), rs.getInt(5), rs.getString(6),rs.getString(7), rs.getString(8), rs.getString(9));
        l.add(u);
            
        }
        return l;
    }

   
    
    
    
}
