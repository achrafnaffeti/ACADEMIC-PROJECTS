/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author ibtihel
 */
public class Utilisateur {
    private int id;
    private String nom;
    private String prenom;
    private String mail;
    private int tel;
    private String login;
    private String password;
    private String type;
    private String activation;

    public String getActivation() {
        return activation;
    }

    public void setActivation(String activation) {
        this.activation = activation;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Utilisateur(int id, String nom, String prenom, String mail, int tel, String login, String password, String type, String activation) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.mail = mail;
        this.tel = tel;
        this.login = login;
        this.password = password;
        this.type = type;
        this.activation = activation;
    }

    public Utilisateur(String login, String password, String type, String activation) {
        this.login = login;
        this.password = password;
        this.type = type;
        this.activation = activation;
    }

    
    

    

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

   
   
    public String toString() {
        return "Utilisateur{" + "login=" + login + 
                 '}';
    }
    
    
}
