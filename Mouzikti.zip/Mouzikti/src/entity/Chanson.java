/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author dhia
 */
public class Chanson {
    private int id;
    private String titre;
    private String album;
    private String genre;
    private String artiste;
    private int nb_vote;
    private String url;

    public Chanson(int id, String titre, String album, String genre, String artiste, int nb_vote, String url) {
        this.id = id;
        this.titre = titre;
        this.album = album;
        this.genre = genre;
        this.artiste = artiste;
        this.nb_vote = nb_vote;
        this.url = url;
    }

    

    public Chanson(String titre, String album, String genre, String artiste, String url) {
        this.titre = titre;
        this.album = album;
        this.genre = genre;
        this.artiste = artiste;
        this.url = url;
    }
    

    public int getId() {
        return id;
    }

    public String getTitre() {
        return titre;
    }

    public String getAlbum() {
        return album;
    }

    public String getGenre() {
        return genre;
    }

    public String getArtiste() {
        return artiste;
    }

    public int getNb_vote() {
        return nb_vote;
    }

    public String getUrl() {
        return url;
    }

   
    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setArtiste(String artiste) {
        this.artiste = artiste;
    }

    public void setNb_vote(int nb_vote) {
        this.nb_vote = nb_vote;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    

    
    
}
