/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package metier;
import dao.UtilisateurDAO;
import entity.Utilisateur;
import java.sql.SQLException;
import java.util.*;
/**
 *
 * @author ibtihel
 */
public class UtilisateurMetier {
    
    private boolean access;
    private boolean accessM;
    private boolean accessA;
    
    public boolean verifyAccess(String login, String password) 
            throws SQLException, ClassNotFoundException{
        
       Iterator<Utilisateur> it=UtilisateurDAO.getInstance().
               getUsers().iterator();
        while(it.hasNext())
        {
            Utilisateur user=it.next();
            if(user.getLogin().equals(login)&&user.getPassword().equals(password)&&user.getType().equals("Administrateur"))
               access=true;
                }
        
        
        
        return access;
    }
    public boolean verifyAccessM(String login, String password) 
            throws SQLException, ClassNotFoundException{
        
       Iterator<Utilisateur> it=UtilisateurDAO.getInstance().
               getUsers().iterator();
        while(it.hasNext())
        {
            Utilisateur user=it.next();
            if(user.getLogin().equals(login)&&user.getPassword().equals(password)&&user.getType().equals("Membre"))
               accessM=true;
                }
        
        
        
        return accessM;
    }
    
    
    public boolean ActivU(String login, String password) 
            throws SQLException, ClassNotFoundException{
        
       Iterator<Utilisateur> it=UtilisateurDAO.getInstance().
               getUsers().iterator();
        while(it.hasNext())
        {
            Utilisateur user=it.next();
            if(user.getActivation().equals("Activé"))
               accessA=true;
                }
        
        
        
        return accessA;
    }
}
