    /*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package technique;
import java.sql.*;
/**
 *
 * @author ibtihel
 */
public class connection {
    private String user="root";
    private String pass="" ;
    private String url="jdbc:mysql://localhost/java" ;
    //"jdbc:oracle:thin:@//localhost/xe"
    private String driver= "com.mysql.jdbc.Driver";
    //"oracle.jdbc.driver.OracleDriver"
    private Connection cn;
    private static connection instanceCn;
     
    private connection() 
            throws ClassNotFoundException, SQLException{
        
        System.out.println("Chargement du Driever");
        Class.forName(driver);
        System.out.println("Driver chargé avec succès");
        cn=DriverManager.getConnection(url, user, pass);
        System.out.println("Connexion établie.");
            }
        public static connection getInstance() 
                throws ClassNotFoundException, SQLException{
        if(instanceCn==null)
            instanceCn=new connection();
        return instanceCn;
    }
    
    
    
      public Connection getCn() {
        return cn;
    }
    
    
}
