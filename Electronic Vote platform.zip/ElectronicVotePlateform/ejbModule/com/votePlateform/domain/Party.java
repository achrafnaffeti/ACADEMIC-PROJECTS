package com.votePlateform.domain;

import java.io.Serializable;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;
import com.votePlateform.domain.Condidat;

/**
 * Entity implementation class for Entity: Party
 *
 */
@Entity
public class Party extends Condidat implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2512562225677125553L;
	private String PasswordParty;
	private String LoginParty;
	private String DescriptionOfParty;
	private String PoliticalAffiliation;
	
	@OneToMany(mappedBy = "partyItem",fetch=FetchType.LAZY)
	private List<MultimediaItem> ListOfItems= new ArrayList<MultimediaItem>();
	@OneToMany(mappedBy = "partyCitizen", fetch = FetchType.EAGER)
	private List<Citizen> ListOfCitizen;
	private String FoundingMember;


	public Party() {
		super();
	}

	public String getFoundingMember() {
		return this.FoundingMember;
	}

	public void setFoundingMember(String FoundingMember) {
		this.FoundingMember = FoundingMember;
	}

	public String getPasswordParty() {
		return this.PasswordParty;
	}

	public void setPasswordParty(String PasswordParty) {
		this.PasswordParty = PasswordParty;
	}

	public String getLoginParty() {
		return this.LoginParty;
	}

	public void setLoginParty(String LoginParty) {
		this.LoginParty = LoginParty;
	}

	public String getDescriptionOfParty() {
		return this.DescriptionOfParty;
	}

	public void setDescriptionOfParty(String DescriptionOfParty) {
		this.DescriptionOfParty = DescriptionOfParty;
	}

	public String getPoliticalAffiliation() {
		return this.PoliticalAffiliation;
	}

	public void setPoliticalAffiliation(String PoliticalAffiliation) {
		this.PoliticalAffiliation = PoliticalAffiliation;
	}

	public List<MultimediaItem> getListOfItems() {
		return ListOfItems;
	}

	public void setListOfItems(List<MultimediaItem> listOfItems) {
		ListOfItems = listOfItems;
	}

	public List<Citizen> getListOfCitizen() {
		return ListOfCitizen;
	}

	public void setListOfCitizen(List<Citizen> listOfCitizen) {
		ListOfCitizen = listOfCitizen;
	}

}
