package com.votePlateform.sevices;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.votePlateform.domain.Citizen;

/**
 * Session Bean implementation class CitizenEJB
 */
@Stateless
public class CitizenEJB implements CitizenEJBRemote {

	/**
	 * Default constructor.
	 */

	@PersistenceContext(name = "ElectronicVotePlateform")
	EntityManager em;

	public CitizenEJB() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void AddCitizen(Citizen citizen) {

		em.persist(citizen);

	}

	@Override
	public void UpdateCitizen(Citizen citizen, int c) {

		Citizen cit = em.find(Citizen.class, c);
		cit.setFirstName(citizen.getFirstName());
		cit.setScondName(citizen.getScondName());
		cit.setCIN(citizen.getCIN());
		cit.setEmail(citizen.getEmail());
		cit.setAdresse(citizen.getAdresse());

		em.merge(cit);
	}

	@Override
	public List<Citizen> SearchCitizen(int cin) {
		// TODO Auto-generated method stub

		return em.createNativeQuery(
				"SELECT * FROM Citizen WHERE CIN like '" + cin + "%';",
				Citizen.class).getResultList();

	}

	@Override
	public void DeleteCitizen(int cin) {
		// TODO Auto-generated method stub

		em.remove(em.find(Citizen.class, cin));

	}

	@Override
	public List<Citizen> DisplayAllCitizen() {

		List<Citizen> listc = new ArrayList<Citizen>();
		javax.persistence.Query query = em
				.createQuery("select c from Citizen c");
		listc = query.getResultList();

		return listc;

	}

	@Override
	public List<Citizen> searchByName(String name) {
		return em
				.createQuery(
						"SELECT cc FROM Citizen cc WHERE cc.FirstName LIKE :name",
						Citizen.class).setParameter("name", "%"+name+"%")
				.getResultList();
	}

}
