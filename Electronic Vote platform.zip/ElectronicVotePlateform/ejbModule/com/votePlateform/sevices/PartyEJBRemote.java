package com.votePlateform.sevices;

import java.util.List;

import javax.ejb.Remote;

import com.votePlateform.domain.MultimediaItem;
import com.votePlateform.domain.Party;

@Remote
public interface PartyEJBRemote {

	public void deleteParty(int id);

	public Party findById(int id);

	public List<Party> findAll();
	
	public List<Party> searchByname(String name);
}
