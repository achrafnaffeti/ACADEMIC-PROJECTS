package com.votePlateform.sevices;

import java.util.List;

import javax.ejb.Stateless;
import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.votePlateform.domain.MultimediaItem;
import com.votePlateform.domain.Party;

/**
 * Session Bean implementation class PartyEJB
 */
@Stateless
public class PartyEJB implements PartyEJBRemote {

	@PersistenceContext(unitName = "ElectronicVotePlateform")
	private EntityManager em;

	/**
	 * Default constructor.
	 */
	public PartyEJB() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void deleteParty(int id) {
		em.remove(em.merge(findById(id)));
	}

	@Override
	public Party findById(int id) {
		return em.find(Party.class, id);
	}

	@Override
	public List<Party> findAll() {
		return em.createQuery("SELECT pp FROM Party pp", Party.class)
				.getResultList();
	}

	@Override
	public List<Party> searchByname(String name) {

		return em
				.createQuery(
						"SELECT ppp FROM Party ppp WHERE ppp.NameCondidate LIKE :name",
						Party.class).setParameter("name", "%" + name + "%")
				.getResultList();
	}
}
