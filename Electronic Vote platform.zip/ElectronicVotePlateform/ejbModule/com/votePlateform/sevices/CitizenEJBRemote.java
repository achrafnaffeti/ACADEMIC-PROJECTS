package com.votePlateform.sevices;

import java.util.List;

import javax.ejb.Remote;

import com.votePlateform.domain.Citizen;

@Remote
public interface CitizenEJBRemote {

	public void AddCitizen(Citizen citizen);

	public void UpdateCitizen(Citizen citizen, int c);

	public void DeleteCitizen(int cin);

	public List<Citizen> SearchCitizen(int cin);

	public List<Citizen> DisplayAllCitizen();
	
	public List<Citizen> searchByName(String name);

}
