package wsa5;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import com.votePlateform.admin.ListSession;
import com.votePlateform.delegate.SessionDelegate;

class ButtonEditor extends DefaultCellEditor {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2240194883583093030L;

	protected JButton button;

	private String label;

	private boolean isPushed;

	public ButtonEditor(JCheckBox checkBox) {
		super(checkBox);
		button = new JButton();
		button.setOpaque(true);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireEditingStopped();
			}
		});
	}

	public Component getTableCellEditorComponent(JTable table, Object value,
			boolean isSelected, int row, int column) {
		label = (value == null) ? "Delete" : value.toString();
		button.setText(label);
		isPushed = true;
		return button;
	}

	public Object getCellEditorValue() {
		if (isPushed) {

			int reply = JOptionPane.showConfirmDialog(null, "selem",
					"delete ?", JOptionPane.YES_NO_OPTION);
			if (reply == JOptionPane.YES_OPTION) {
			//	SessionDelegate.deleteSession((int)ListSession.IdSelected);
				System.out.println(ListSession.IdSelected);
			}

		}
		isPushed = false;
		return new String(label);
	}

	public boolean stopCellEditing() {
		isPushed = false;
		return super.stopCellEditing();
	}

	protected void fireEditingStopped() {
		super.fireEditingStopped();
	}
}
