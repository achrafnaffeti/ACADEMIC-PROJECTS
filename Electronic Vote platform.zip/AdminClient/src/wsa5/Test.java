package wsa5;

import java.util.List;

import com.votePlateform.delegate.CitizenDelegate;
import com.votePlateform.delegate.MultimediaItemDelegate;
import com.votePlateform.delegate.PartyDelegate;
import com.votePlateform.delegate.SessionDelegate;
import com.votePlateform.domain.Citizen;
import com.votePlateform.domain.MultimediaItem;
import com.votePlateform.domain.Party;
import com.votePlateform.domain.Session;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Party p = new Party();
		p.setDescriptionOfParty("aaaa");
		p.setFoundingMember("aziz");
		p.setLoginCondidate("aziz");
		p.setPasswordParty("aziz");

		List<Party> pp = PartyDelegate.findAll();
		for (Party party : pp) {
			System.out.println(party.getDescriptionOfParty());
			List<Citizen> c = party.getListOfCitizen();
			List<MultimediaItem> m = MultimediaItemDelegate.findByParty(party.getIdCondidat());
			for (MultimediaItem multimediaItem : m) {
				System.out.println(multimediaItem.getDescriptionOfItem());
			}
			for (Citizen citizen : c) {
				System.out.println(citizen.getCIN());
			}
		}

		// CitizenDelegate.findByIdParty(1);
	}

}
