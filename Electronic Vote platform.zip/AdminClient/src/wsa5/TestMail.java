package wsa5;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

public class TestMail {

	public static void main(String[] args) {
		String From = "mohamedazizbenrejeb@gmail.com";
		String To_addr = "mohamedaziz.benrejeb@esprit.tn";
		String Subject = "selem";
		String Text_containt = "selem";
		Properties props = new Properties();
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.user", "gearsteam2014@gmail.com");
		props.put("mail.smtp. password", "gears123456");
		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(
								"gearsteam2014@gmail.com", "gears123456");
					}
				}

		);
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(From));
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(To_addr));
			message.setSubject(Subject);
			message.setText(Text_containt);
			Transport.send(message);
			System.out.println("ok");
		} catch (Exception exception) {
			System.out.println(exception);
		}

	}

}
