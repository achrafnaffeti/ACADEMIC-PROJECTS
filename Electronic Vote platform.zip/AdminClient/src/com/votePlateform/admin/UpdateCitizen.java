package com.votePlateform.admin;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.votePlateform.delegate.CitizenDelegate;
import com.votePlateform.domain.Citizen;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UpdateCitizen extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtCin;
	private JTextField txtName;
	private JTextField txtLastName;
	private JTextField txtEmail;
	private JTextField txtAddress;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UpdateCitizen dialog = new UpdateCitizen();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public UpdateCitizen() {
		getContentPane().setLayout(null);
		setTitle("Update Citizen");
		setBounds(100, 100, 355, 262);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblCin = new JLabel("CIN");
			lblCin.setBounds(68, 37, 66, 14);
			contentPanel.add(lblCin);
		}
		{
			JLabel lblName = new JLabel("Name");
			lblName.setBounds(68, 62, 66, 14);
			contentPanel.add(lblName);
		}
		{
			JLabel lblLastName = new JLabel("Last name");
			lblLastName.setBounds(68, 87, 66, 14);
			contentPanel.add(lblLastName);
		}
		{
			JLabel lblEmail = new JLabel("E-mail");
			lblEmail.setBounds(68, 112, 66, 14);
			contentPanel.add(lblEmail);
		}
		{
			JLabel lblAddress = new JLabel("Address");
			lblAddress.setBounds(68, 135, 66, 14);
			contentPanel.add(lblAddress);
		}
		{
			txtCin = new JTextField();
			txtCin.setEditable(false);
			txtCin.setBounds(144, 34, 108, 20);
			contentPanel.add(txtCin);
			txtCin.setColumns(10);
		}
		{
			txtName = new JTextField();
			txtName.setColumns(10);
			txtName.setBounds(144, 59, 108, 20);
			contentPanel.add(txtName);
		}
		{
			txtLastName = new JTextField();
			txtLastName.setColumns(10);
			txtLastName.setBounds(144, 84, 108, 20);
			contentPanel.add(txtLastName);
		}
		{
			txtEmail = new JTextField();
			txtEmail.setColumns(10);
			txtEmail.setBounds(144, 109, 108, 20);
			contentPanel.add(txtEmail);
		}
		{
			txtAddress = new JTextField();
			txtAddress.setColumns(10);
			txtAddress.setBounds(144, 132, 108, 20);
			contentPanel.add(txtAddress);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Update");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (txtAddress.getText().equals("")
								|| txtEmail.getText().equals("")
								|| txtName.getText().equals("")
								|| txtLastName.getText().equals("")) {
							JOptionPane.showMessageDialog(null,
									"One or Several fields are blank");
						} else if (validateEmail(txtEmail.getText()) == false) {
							JOptionPane.showMessageDialog(null,
									"Email incorrect format \n email@email.fr");
							txtEmail.requestFocus();
						} else {

							Citizen c = new Citizen();
							c.setCIN(ListCitizen.cinCitizen);
							c.setAdresse(txtAddress.getText());
							c.setEmail(txtEmail.getText());
							c.setFirstName(txtName.getText());
							c.setScondName(txtLastName.getText());
							CitizenDelegate.Modifycitizen(c,
									ListCitizen.cinCitizen);
							ListCitizen.refreshTable();
							dispose();
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton btnDelete = new JButton("Delete");
				btnDelete.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						int reply = JOptionPane.showConfirmDialog(null,
								"you want to delete ?", "delete ?",
								JOptionPane.YES_NO_OPTION);
						if (reply == JOptionPane.YES_OPTION) {
							CitizenDelegate
									.Deletecitizen(ListCitizen.cinCitizen);
							ListCitizen.refreshTable();
							dispose();
							SendEmail(ListCitizen.emailCitizen);
						}
					}
				});
				buttonPane.add(btnDelete);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((dim.width / 2) - (this.getSize().width / 2),
				(dim.height / 2) - (this.getSize().height / 2));
		init();
	}

	private void init() {
		txtCin.setText("" + ListCitizen.cinCitizen);
		txtAddress.setText(ListCitizen.addressCitizen);
		txtEmail.setText(ListCitizen.emailCitizen);
		txtLastName.setText(ListCitizen.lastNameCitizen);
		txtName.setText(ListCitizen.nameCitizen);
	}

	public static boolean validateEmail(String email) {
		boolean status = false;
		String EMAIL_PATTERN = "[a-zA-Z0-9[!#$%&'()*+,/\\-_\\.\\\"]]+@[a-zA-Z0-9[!#$%&'()*+,/\\-_\\\"]]+\\.[a-zA-Z0-9[!#$%&'()*+,/\\-_\\\"\\.]]+";
		Pattern pattern = Pattern.compile(EMAIL_PATTERN);
		Matcher matcher = pattern.matcher(email);
		if (matcher.matches()) {
			status = true;
		} else {
			status = false;
		}
		return status;
	}

	private void SendEmail(String to) {
		String From = "gearsteam2014@gmail.com";
		String To_addr = to;
		String Subject = "delete account";
		String Text_containt = "The administrator to delete your account due to misuse of your account,\n Please Contact the administrator.\n \n kind regards";
		Properties props = new Properties();
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.user", "gearsteam2014@gmail.com");
		props.put("mail.smtp. password", "gears123456");
		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(
								"gearsteam2014@gmail.com", "gears123456");
					}
				}

		);
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(From));
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(To_addr));
			message.setSubject(Subject);
			message.setText(Text_containt);
			Transport.send(message);
			System.out.println("ok");
		} catch (Exception exception) {
			System.out.println(exception);
		}

	}

}
