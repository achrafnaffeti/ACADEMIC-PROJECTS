package com.votePlateform.admin;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;
import com.toedter.components.JSpinField;
import com.votePlateform.delegate.SessionDelegate;
import com.votePlateform.domain.Session;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Date;
import javax.swing.JTextArea;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;

public class AddSession extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1291554093929247670L;
	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			AddSession dialog = new AddSession();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public AddSession() {

		setModal(true);
		setResizable(false);
		setTitle("Add new session");
		setBounds(100, 100, 463, 251);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(null);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel);
		{
			JCalendar calendar = new JCalendar();
			contentPanel.add(calendar);
		}

		JLabel lblNewLabel = new JLabel("Openning date");
		lblNewLabel.setBounds(12, 18, 79, 20);
		contentPanel.add(lblNewLabel);

		final JDateChooser dCOpenning = new JDateChooser();
		dCOpenning.setDateFormatString("dd/MM/yyyy");
		dCOpenning.setBounds(101, 18, 103, 20);

		contentPanel.add(dCOpenning);

		final JSpinField spinHourOpenning = new JSpinField(0,23);
		
		spinHourOpenning.getSpinner().addInputMethodListener(new InputMethodListener() {
			public void caretPositionChanged(InputMethodEvent arg0) {
			}
			public void inputMethodTextChanged(InputMethodEvent arg0) {
			
			}
		});
		spinHourOpenning.getSpinner().addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent arg0) {
				
			}
		});
		spinHourOpenning.setBounds(214, 18, 38, 20);
		spinHourOpenning.setName("spinHourOpenning");
		contentPanel.add(spinHourOpenning);

		final JSpinField spinMinuteOpenning = new JSpinField(0,60);
		spinMinuteOpenning.setBounds(288, 18, 40, 20);
		contentPanel.add(spinMinuteOpenning);

		JLabel lblH = new JLabel("H");
		lblH.setBounds(262, 17, 46, 21);
		contentPanel.add(lblH);

		JLabel lblMin = new JLabel("Min");
		lblMin.setBounds(342, 18, 46, 20);
		contentPanel.add(lblMin);

		JLabel lblNewLabel_1 = new JLabel("Ending date");
		lblNewLabel_1.setBounds(12, 66, 79, 20);
		contentPanel.add(lblNewLabel_1);

		final JDateChooser dCEnding = new JDateChooser();
		dCEnding.setDateFormatString("dd/MM/yyyy");
		dCEnding.setBounds(101, 66, 103, 20);
		contentPanel.add(dCEnding);

		final JSpinField spinHourEnding = new JSpinField(0,24);
		spinHourEnding.setBounds(214, 66, 38, 20);
		contentPanel.add(spinHourEnding);

		JLabel label = new JLabel("H");
		label.setBounds(262, 66, 46, 21);
		contentPanel.add(label);

		final JSpinField spinMinuteEnding = new JSpinField(0,60);
		spinMinuteEnding.setBounds(288, 66, 40, 20);
		contentPanel.add(spinMinuteEnding);

		JLabel label_1 = new JLabel("Min");
		label_1.setBounds(342, 69, 46, 20);
		contentPanel.add(label_1);

		JLabel lblDescription = new JLabel("Description");
		lblDescription.setBounds(12, 124, 79, 14);
		contentPanel.add(lblDescription);

		final JTextArea txtDescription = new JTextArea();
		txtDescription.setBounds(101, 97, 227, 61);
		contentPanel.add(txtDescription);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {

						if (dCEnding.getDate() == null
								|| dCEnding.getDate() == null) {
							JOptionPane.showMessageDialog(null,
									"Please fill in the blanks !");
						} else if (new Date().after(dCEnding.getDate())
								|| new Date().after(dCOpenning.getDate())) {
							JOptionPane.showMessageDialog(null,
									"Dates must be greater than today's date");
						} else if (dCOpenning.getDate().after(
								dCEnding.getDate()))
							JOptionPane.showMessageDialog(null,
									"end date must be after the start date");
						else {

							Session session = new Session();
							Date dO = dCOpenning.getDate();
							dO.setHours(spinHourOpenning.getValue());
							dO.setMinutes(spinMinuteOpenning.getValue());
							dO.setSeconds(0);
							session.setOpeningDateOfSession(dO);
							Date dE = dCEnding.getDate();
							dE.setHours(spinHourEnding.getValue());
							dE.setMinutes(spinMinuteEnding.getValue());
							dE.setSeconds(0);
							session.setEndingDateOfSession(dE);
							session.setDescriptionOfSession(txtDescription
									.getText());
							SessionDelegate.addSession(session);
							JOptionPane.showMessageDialog(null,
									" Session was added ! ");
							dispose();
							ListSession.refreshTable();
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
