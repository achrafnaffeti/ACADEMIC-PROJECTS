package com.votePlateform.admin;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.votePlateform.delegate.CitizenDelegate;
import com.votePlateform.domain.Citizen;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTextField;

import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;
import javax.swing.JLabel;

public class ListCitizen extends JInternalFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7716405571618268127L;
	private static JTable tblVoter;
	private static java.util.List<Citizen> myList;
	JButton btnExit;
	public static int cinCitizen;
	public static String nameCitizen;
	public static String lastNameCitizen;
	public static String emailCitizen;
	public static String addressCitizen;
	private JTextField txtSearchByName;
	private JLabel lblRecherche;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListCitizen frame = new ListCitizen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ListCitizen() {
		setTitle("List of citizen");
		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent arg0) {
				tblVoter.setSize(getParent().getSize().width, getParent()
						.getSize().height - 80);
				btnExit.setBounds(getParent().getSize().width - 110,
						getParent().getSize().height - 65, 89, 23);
				txtSearchByName.setBounds(getParent().getSize().width - 135,
						15, 115, 25);

			}
		});
		setBounds(100, 100, 575, 382);

		getContentPane().setLayout(null);

		btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnExit.setBounds(460, 318, 89, 23);
		getContentPane().add(btnExit);
		tblVoter = new JTable();
		tblVoter.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (arg0.getClickCount() == 2 && tblVoter.getSelectedRow() != 0) {
					DefaultTableModel model = (DefaultTableModel) tblVoter
							.getModel();
					cinCitizen = (int) model.getValueAt(
							tblVoter.getSelectedRow(), 0);
					nameCitizen = (String) model.getValueAt(
							tblVoter.getSelectedRow(), 1);
					lastNameCitizen = (String) model.getValueAt(
							tblVoter.getSelectedRow(), 2);
					emailCitizen = (String) model.getValueAt(
							tblVoter.getSelectedRow(), 3);
					addressCitizen = (String) model.getValueAt(
							tblVoter.getSelectedRow(), 4);
					UpdateCitizen update = new UpdateCitizen();
					update.setVisible(true);
				}
			}
		});
		tblVoter.setBounds(10, 47, 539, 257);
		getContentPane().add(tblVoter);
		tblVoter.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "Citizen CIN", "Name", "Last name", "E-mail",
						"Address" }) {
			private static final long serialVersionUID = 5403468916125701088L;
			boolean[] columnEditables = new boolean[] { false, false, false,
					false, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});

		txtSearchByName = new JTextField();
		txtSearchByName.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				if (txtSearchByName.getText().isEmpty()) {
					refreshTable();
					lblRecherche.setText("");
				} else {
					DefaultTableModel dm = (DefaultTableModel) tblVoter
							.getModel();
					dm.getDataVector().removeAllElements();
					List<Citizen> lst = CitizenDelegate
							.findByName(txtSearchByName.getText());
					if (lst.isEmpty()) {
						lblRecherche.setText("no Citizen name '"
								+ txtSearchByName.getText() + "'");
					} else {
						String[] columnNames = { "Citizen CIN", "Name",
								"Last name", "E-mail", "Address" };
						dm.addRow(columnNames);
						for (Citizen citizen : lst) {
							dm.addRow(new Object[] { citizen.getCIN(),
									citizen.getFirstName(),
									citizen.getScondName(), citizen.getEmail(),
									citizen.getAdresse() });
						}
						lblRecherche.setText("");
					}
				}
			}
		});
		txtSearchByName.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				txtSearchByName.setText("");
			}

			@Override
			public void focusLost(FocusEvent e) {
				txtSearchByName.setText("Search by name ...");
			}
		});
		txtSearchByName.setText("Search by name ...");
		txtSearchByName.setForeground(Color.GRAY);
		txtSearchByName.setColumns(10);
		txtSearchByName.setBounds(434, 11, 115, 25);
		getContentPane().add(txtSearchByName);

		lblRecherche = new JLabel("");
		lblRecherche.setForeground(Color.RED);
		lblRecherche.setBounds(279, 16, 145, 14);
		getContentPane().add(lblRecherche);
		DisplayTable();
	}

	public static void DisplayTable() {
		myList = CitizenDelegate.DisplayAllCitizen();
		DefaultTableModel model = (DefaultTableModel) tblVoter.getModel();
		String[] columnNames = { "Citizen CIN", "Name", "Last name", "E-mail",
				"Address" };
		model.addRow(columnNames);
		for (Citizen citizen : myList) {
			model.addRow(new Object[] { citizen.getCIN(),
					citizen.getFirstName(), citizen.getScondName(),
					citizen.getEmail(), citizen.getAdresse() });
		}
	}

	public static void refreshTable() {
		DefaultTableModel dm = (DefaultTableModel) tblVoter.getModel();
		dm.getDataVector().removeAllElements();
		DisplayTable();
	}
}
