package com.votePlateform.admin;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.List;
import java.awt.Toolkit;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JLabel;

import com.votePlateform.delegate.PartyDelegate;
import com.votePlateform.domain.Citizen;
import com.votePlateform.domain.MultimediaItem;

import java.awt.Font;
import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JSeparator;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DetailOfParty extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable tblMultimedia;
	private JTable tblCitizen;

	java.util.List<Citizen> listCitizen;
	java.util.List<MultimediaItem> listMultimedia;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DetailOfParty dialog = new DetailOfParty();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DetailOfParty() {

		listCitizen = new ArrayList<Citizen>();
		listMultimedia = new ArrayList<MultimediaItem>();
		getContentPane().setLayout(null);
		setTitle("Details of party");
		setBounds(100, 100, 716, 389);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		tblMultimedia = new JTable();
		tblMultimedia.setBounds(366, 39, 324, 259);
		contentPanel.add(tblMultimedia);

		tblCitizen = new JTable();
		tblCitizen.setBounds(10, 42, 324, 259);
		contentPanel.add(tblCitizen);

		JLabel lblCitizen = new JLabel("Members");
		lblCitizen.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblCitizen.setBounds(10, 14, 101, 17);
		contentPanel.add(lblCitizen);

		JLabel lblMultimedia = new JLabel("Multimedia");
		lblMultimedia.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblMultimedia.setBounds(366, 14, 94, 17);
		contentPanel.add(lblMultimedia);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnDelete = new JButton("Delete");
				btnDelete.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						int reply = JOptionPane.showConfirmDialog(null,
								"you want to delete ?", "delete ?",
								JOptionPane.YES_NO_OPTION);
						if (reply == JOptionPane.YES_OPTION) {
							PartyDelegate.deleteParty((int) ListParty.idParty);
							ListParty.refreshTable();
							dispose();
						}
					}
				});
				btnDelete.setActionCommand("OK");
				buttonPane.add(btnDelete);
				getRootPane().setDefaultButton(btnDelete);
			}
			{
				JButton cancelButton = new JButton("Exit");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}

		tblCitizen.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "CIN", "First name", "Second name", "Adress",
						"Email" }) {
			private static final long serialVersionUID = 5403468916125701088L;
			boolean[] columnEditables = new boolean[] { false, false, false,
					false, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});

		tblMultimedia.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "type", "Description", "Path" }) {
			private static final long serialVersionUID = 5403468916125701088L;
			boolean[] columnEditables = new boolean[] { false, false, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});

		JSeparator separator = new JSeparator();
		separator.setBounds(349, 14, 1, 292);
		contentPanel.add(separator);

		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(333, 0, 1, 2);
		contentPanel.add(separator_1);
		DisplayCitizen();
		DisplayMultimedia();
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((dim.width / 2) - (this.getSize().width / 2),
				(dim.height / 2) - (this.getSize().height / 2));
	}

	public void DisplayCitizen() {
		listCitizen = ListParty.lstCitizen;
		DefaultTableModel model = (DefaultTableModel) tblCitizen.getModel();
		String[] columnNames = { "CIN", "First name", "Second name", "Adress",
				"Email" };
		model.addRow(columnNames);

		for (Citizen citizen : listCitizen) {
			model.addRow(new Object[] { citizen.getCIN(),
					citizen.getFirstName(), citizen.getScondName(),
					citizen.getAdresse(), citizen.getEmail() });
		}
	}

	public void DisplayMultimedia() {
		listMultimedia = ListParty.lstMultimedia;
		DefaultTableModel model = (DefaultTableModel) tblMultimedia.getModel();
		String[] columnNames = { "type", "Description", "Path" };
		model.addRow(columnNames);

		for (MultimediaItem multimedia : listMultimedia) {
			model.addRow(new Object[] { multimedia.getTypeOfItem(),
					multimedia.getDescriptionOfItem(), multimedia.getPath() });
		}
	}


}
