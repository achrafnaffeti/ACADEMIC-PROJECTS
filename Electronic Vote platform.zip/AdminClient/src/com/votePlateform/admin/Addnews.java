package com.votePlateform.admin;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import com.votePlateform.domain.MultimediaItem;
import com.votePlateform.delegate.MultimediaItemDelegate;

import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class Addnews extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1291554093929247670L;
	private final JPanel contentPanel = new JPanel();
	private JTextField field;
	private File fileToSave;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Addnews dialog = new Addnews();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Addnews() {

		setModal(true);
		setResizable(false);
		setTitle("Add new News");
		setBounds(100, 100, 415, 268);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(null);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel);

		JLabel lblNewLabel_1 = new JLabel("Desription");
		lblNewLabel_1.setBounds(12, 52, 58, 20);
		contentPanel.add(lblNewLabel_1);

		JLabel lblTitle = new JLabel("Type");
		lblTitle.setBounds(12, 27, 46, 14);
		contentPanel.add(lblTitle);

		final JTextField textField = new JTextField();
		textField.setBounds(77, 56, 301, 63);
		contentPanel.add(textField);
		textField.setColumns(10);

		final JButton button = new JButton("Upload File");
		button.setBounds(267, 130, 111, 23);
		contentPanel.add(button);

		field = new JTextField();
		field.setBounds(12, 130, 245, 23);
		contentPanel.add(field);
		field.setColumns(10);

		final JComboBox comboBox = new JComboBox();
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				if (comboBox.getSelectedIndex() == 0) {
					field.setVisible(false);
					button.setVisible(false);
				} else {
					field.setVisible(true);
					button.setVisible(true);
				}
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "Text",
				"Picture", "Video" }));
		comboBox.setToolTipText("");
		comboBox.setBounds(293, 24, 85, 20);
		contentPanel.add(comboBox);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Chooser frame = new Chooser();
				fileToSave = frame.GetFileToSave();
				field.setText(fileToSave.getName());
			}
		});
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if (comboBox.getSelectedIndex() == 2) {
							JOptionPane.showMessageDialog(null,
									"in Construction \n Sprint 2 'ASP.NET'");
							return;
						}
						MultimediaItem m = new MultimediaItem();
						m.setTypeOfItem(comboBox.getSelectedItem().toString());
						m.setDescriptionOfItem(textField.getText().toString());

						if (comboBox.getSelectedIndex() == 1) {
							m.setPath(field.getText().toString());

							File f = new File("src/com/votePlateform/files/"
									+ fileToSave.getName());
							Path FROM = Paths.get(fileToSave.getPath());
							Path TO = Paths.get(f.getPath());
							// overwrite existing file, if exists
							CopyOption[] options = new CopyOption[] {
									StandardCopyOption.REPLACE_EXISTING,
									StandardCopyOption.COPY_ATTRIBUTES };
							try {
								Files.copy(FROM, TO, options);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}

						MultimediaItemDelegate.addMultimedia(m);
						ListNews.refreshTable();
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		field.setVisible(false);
		button.setVisible(false);
	}

}

class Chooser extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8296600484562373816L;
	JFileChooser chooser;
	String fileName;
	File f;

	public Chooser() {
		chooser = new JFileChooser();
		int r = chooser.showOpenDialog(new JFrame());
		if (r == JFileChooser.APPROVE_OPTION) {
			fileName = chooser.getSelectedFile().getPath();
			f = chooser.getSelectedFile();
		}
	}

	public File GetFileToSave() {
		return f;
	}
}
