package com.votePlateform.admin;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.votePlateform.delegate.SessionDelegate;
import com.votePlateform.domain.Session;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Date;

import com.toedter.calendar.JCalendar;

import javax.swing.JLabel;

import com.toedter.calendar.JDateChooser;
import com.toedter.components.JSpinField;

import javax.swing.JTextArea;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

public class UpdateSession extends JDialog {

	/**
	 * 
	 */
	JDateChooser dCOpening;
	JSpinField spinHOpening;
	JSpinField spinMOpening;
	JDateChooser dCEnding;
	JSpinField spinHEnding;
	JSpinField spinMEnding;
	JTextArea txtDescription;
	private static final long serialVersionUID = -8174120452315483932L;
	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UpdateSession dialog = new UpdateSession();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public UpdateSession() {
		setModal(true);
		setResizable(false);
		setTitle("Update session");

		setBounds(100, 100, 457, 243);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel.setBounds(0, 0, 450, 162);
		contentPanel.add(panel);

		JCalendar calendar = new JCalendar();
		calendar.setBounds(0, 0, 0, 0);
		panel.add(calendar);

		JLabel label = new JLabel("Openning date");
		label.setBounds(12, 18, 79, 20);
		panel.add(label);

		dCOpening = new JDateChooser();
		dCOpening.setDateFormatString("dd/MM/yyyy");
		dCOpening.setBounds(101, 18, 103, 20);
		panel.add(dCOpening);

		spinHOpening = new JSpinField(0,23);
		spinHOpening.getSpinner().addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				
			}
		});
		spinHOpening.setName("spinHourOpenning");
		spinHOpening.setBounds(214, 18, 38, 20);
		panel.add(spinHOpening);

		spinMOpening = new JSpinField(0,60);
		spinMOpening.setBounds(288, 18, 40, 20);
		panel.add(spinMOpening);

		JLabel label_1 = new JLabel("H");
		label_1.setBounds(262, 17, 46, 21);
		panel.add(label_1);

		JLabel label_2 = new JLabel("Min");
		label_2.setBounds(342, 18, 46, 20);
		panel.add(label_2);

		JLabel label_3 = new JLabel("Ending date");
		label_3.setBounds(12, 66, 79, 20);
		panel.add(label_3);

		dCEnding = new JDateChooser();
		dCEnding.setDateFormatString("dd/MM/yyyy");
		dCEnding.setBounds(101, 66, 103, 20);
		panel.add(dCEnding);

		spinHEnding = new JSpinField(0,23);
		spinHEnding.setBounds(214, 66, 38, 20);
		panel.add(spinHEnding);

		JLabel label_4 = new JLabel("H");
		label_4.setBounds(262, 66, 46, 21);
		panel.add(label_4);

		spinMEnding = new JSpinField(0,60);
		spinMEnding.setBounds(288, 66, 40, 20);
		panel.add(spinMEnding);

		JLabel label_5 = new JLabel("Min");
		label_5.setBounds(342, 69, 46, 20);
		panel.add(label_5);

		JLabel label_6 = new JLabel("Description");
		label_6.setBounds(12, 123, 79, 14);
		panel.add(label_6);

		txtDescription = new JTextArea();
		txtDescription.setBounds(101, 103, 227, 48);
		panel.add(txtDescription);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Update");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if (dCEnding.getDate() == null
								|| dCEnding.getDate() == null) {
							JOptionPane.showMessageDialog(null,
									"Please fill in the blanks !");
						} else if (new Date().after(dCEnding.getDate())
								|| new Date().after(dCOpening.getDate())) {
							JOptionPane.showMessageDialog(null,
									"Dates must be greater than today's date");
						} else if (dCOpening.getDate().after(
								dCEnding.getDate()))
							JOptionPane.showMessageDialog(null,
									"end date must be after the start date");
						else {

							Session session = new Session();
							Date dO = dCOpening.getDate();
							dO.setHours(spinHOpening.getValue());
							dO.setMinutes(spinMOpening.getValue());
							dO.setSeconds(0);
							session.setOpeningDateOfSession(dO);
							Date dE = dCEnding.getDate();
							dE.setHours(spinHEnding.getValue());
							dE.setMinutes(spinMEnding.getValue());
							dE.setSeconds(0);
							session.setEndingDateOfSession(dE);
							session.setDescriptionOfSession(txtDescription
									.getText());
							session.setIdSession(ListSession.IdSelected);
							SessionDelegate.updateSession(session);
							JOptionPane.showMessageDialog(null,
									" Session was updated ! ");
							dispose();
							ListSession.refreshTable();
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}

			JButton btnDelete = new JButton("Delete");
			btnDelete.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					int reply = JOptionPane.showConfirmDialog(null,
							"you want to delete ?", "delete ?",
							JOptionPane.YES_NO_OPTION);
					if (reply == JOptionPane.YES_OPTION) {
						SessionDelegate
								.deleteSession((int) ListSession.IdSelected);
						ListSession.refreshTable();
						dispose();
					}
				}
			});
			buttonPane.add(btnDelete);
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((dim.width / 2) - (this.getSize().width / 2),
				(dim.height / 2) - (this.getSize().height / 2));
		Opening();
	}

	private void Opening() {
		dCOpening.setDate(ListSession.SessiondateOp);
		dCEnding.setDate(ListSession.SessionDateEn);
		txtDescription.setText(ListSession.SessionDescription);
		spinHOpening.setValue(ListSession.SessiondateOp.getHours());
		spinMOpening.setValue(ListSession.SessiondateOp.getMinutes());
		spinHEnding.setValue(ListSession.SessionDateEn.getHours());
		spinMEnding.setValue(ListSession.SessionDateEn.getMinutes());
	}
}
