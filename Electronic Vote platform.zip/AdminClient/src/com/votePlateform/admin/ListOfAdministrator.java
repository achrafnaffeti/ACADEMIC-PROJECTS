package com.votePlateform.admin;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JTable;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;
import javax.swing.table.DefaultTableModel;

import com.votePlateform.delegate.AuthAdminDelegate;
import com.votePlateform.domain.IsieAdmin;

@SuppressWarnings("serial")
public class ListOfAdministrator extends JInternalFrame {
	public static String name;
	public static String surname;
	public static String login;
	public static String passwd;

	private static JTable tblNews;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					ListOfAdministrator frame = new ListOfAdministrator();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ListOfAdministrator() {
		final JButton btnExit = new JButton("Exit");
		btnExit.setBounds(608, 375, 89, 23);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});

		addInternalFrameListener(new InternalFrameAdapter() {
			@Override
			public void internalFrameOpened(InternalFrameEvent arg0) {
				DisplayTable();
			}
		});
		setTitle("List of Admin");
		setBounds(100, 100, 723, 443);
		getContentPane().setLayout(null);

		getContentPane().add(btnExit);

		tblNews = new JTable();

		tblNews.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {

				if (arg0.getClickCount() == 2 && tblNews.getSelectedRow() != 0) {
					DefaultTableModel model = (DefaultTableModel) tblNews
							.getModel();
					// txtUpdate1 = model.getValueAt(
					// tblNews.getSelectedRow(), 0).toString();
					name = (String) model.getValueAt(tblNews.getSelectedRow(),
							1); // name
					surname = (String) model.getValueAt(
							tblNews.getSelectedRow(), 2); // second name
					login = (String) model.getValueAt(tblNews.getSelectedRow(),
							3); // Login
					passwd = (String) model.getValueAt(
							tblNews.getSelectedRow(), 3);
					
					
					UpdateAdmin updateAdmin = new UpdateAdmin();
					updateAdmin.setId((int) model.getValueAt(
							tblNews.getSelectedRow(), 0)); // id
					updateAdmin.setVisible(true);
				}
			}
		});
		tblNews.setModel(new DefaultTableModel(new Object[][] {}, new String[] {
				"", "", "", "", "" }) {
			private static final long serialVersionUID = 5403468916125701088L;
			boolean[] columnEditables = new boolean[] { false, false, false,
					false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});

		tblNews.setBounds(10, 11, 687, 353);
		getContentPane().add(tblNews);

	}

	static String[] columnNames = { "Id", "Name", "Second Name", "Login",
			"Passwd" };

	public static void DisplayTable() {
		DefaultTableModel model = (DefaultTableModel) tblNews.getModel();

		tblNews.getColumnModel().getColumn(0).setMinWidth(0);
		tblNews.getColumnModel().getColumn(0).setMaxWidth(0);
		tblNews.getColumnModel().getColumn(0).setWidth(0);

		List<IsieAdmin> listeadmin = new ArrayList<IsieAdmin>();
		listeadmin = AuthAdminDelegate.findAll();
		System.out.println(listeadmin.size());
		model.addRow(columnNames);

		for (IsieAdmin isieadmin : listeadmin) {

			model.addRow(new Object[] { isieadmin.getIdAdmin(),
					isieadmin.getAdminName(), isieadmin.getAdminSecondName(),
					isieadmin.getLoginAdmin(), isieadmin.getPasswordAdmin() });
		}
	}

	public static void refreshTable() {
		DefaultTableModel dm = (DefaultTableModel) tblNews.getModel();
		dm.getDataVector().removeAllElements();
		DisplayTable();
	}

}