package com.votePlateform.admin;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import com.votePlateform.domain.IsieAdmin;
import com.votePlateform.domain.MultimediaItem;
import com.votePlateform.delegate.AuthAdminDelegate;
import com.votePlateform.delegate.MultimediaItemDelegate;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPasswordField;

public class UpdateAdmin extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8174127452315483932L;
	private final JPanel contentPanel = new JPanel();
	private JTextField txt2;
	private JTextField txt3;
	private JTextField field;
	private int id;
	private JTextField textField;
	private JPasswordField passwordField;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UpdateNews dialog = new UpdateNews();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public UpdateAdmin() {
		setModal(true);
		setResizable(false);
		setTitle("Update Admin");

		setBounds(100, 100, 416, 274);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		txt2 = new JTextField();
		txt2.setBounds(112, 27, 180, 25);
		contentPanel.add(txt2);
		txt2.setColumns(10);

		txt3 = new JTextField();
		txt3.setBounds(112, 70, 180, 25);
		contentPanel.add(txt3);
		txt3.setColumns(10);

		JLabel lblTitle = new JLabel("Second Name");
		lblTitle.setBounds(10, 73, 76, 14);
		contentPanel.add(lblTitle);

		JLabel lblDescription = new JLabel("Name");
		lblDescription.setBounds(10, 30, 76, 14);
		contentPanel.add(lblDescription);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setBounds(10, 117, 46, 14);
		contentPanel.add(lblLogin);
		
		JLabel lblPasswd = new JLabel("Passwd");
		lblPasswd.setBounds(10, 155, 46, 14);
		contentPanel.add(lblPasswd);
		
		textField = new JTextField();
		textField.setBounds(112, 114, 180, 25);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(112, 152, 180, 25);
		contentPanel.add(passwordField);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {

						IsieAdmin m = AuthAdminDelegate.serachAdminById(id);
						m.setAdminName(txt2.getText().toString());
						m.setAdminSecondName(txt3.getText().toString());
						m.setLoginAdmin(textField.getText().toString());
						m.setPasswordAdmin(passwordField.getText().toString());
						AuthAdminDelegate.UpdateAdmin(m);
						ListOfAdministrator.refreshTable();
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
				{
					JButton cancelButton = new JButton("Cancel");
					cancelButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							dispose();
						}
					});
					cancelButton.setActionCommand("Cancel");
					buttonPane.add(cancelButton);
				}

				JButton btnNewButton = new JButton("Delete");
				btnNewButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						int reply = JOptionPane.showConfirmDialog(null,
								"you want to delete ?", "delete ?",
								JOptionPane.YES_NO_OPTION);
						if (reply == JOptionPane.YES_OPTION) {
							IsieAdmin m = AuthAdminDelegate.serachAdminById(id);
							AuthAdminDelegate.removeAdminIsie(m);
							ListOfAdministrator.refreshTable();
							dispose();
						}
						
					}
				});
				buttonPane.add(btnNewButton);
			}
		}

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((dim.width / 2) - (this.getSize().width / 2),
				(dim.height / 2) - (this.getSize().height / 2));

		setText();
	}

	private void setText() {
		txt2.setText(ListOfAdministrator.name);
		txt3.setText(ListOfAdministrator.surname);
		textField.setText(ListOfAdministrator.login);
	}
}
