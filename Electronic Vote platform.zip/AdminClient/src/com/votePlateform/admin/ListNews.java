package com.votePlateform.admin;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import com.votePlateform.domain.MultimediaItem;
import com.votePlateform.delegate.MultimediaItemDelegate;

@SuppressWarnings("serial")
public class ListNews extends JInternalFrame {
	public static int idNews;
	public static String DescriptionNews;
	public static String pathNews;
	public static String typeNews;
	public static ImageIcon iconNews;
	private static JTable tblNews;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					ListNews frame = new ListNews();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ListNews() {
		
		final JButton btnExit = new JButton("Exit");
		btnExit.setBounds(608, 375, 89, 23);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});

		final JButton btnAddNews = new JButton("Add new news");
		btnAddNews.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Addnews newAddnews = new Addnews();
				Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
				newAddnews.setLocation(dim.width / 2
						- newAddnews.getSize().width / 2, dim.height / 2
						- newAddnews.getSize().height / 2);
				newAddnews.setVisible(true);
			}
		});
		btnAddNews.setBounds(10, 375, 158, 23);

		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent arg0) {
				tblNews.setSize(getParent().getSize().width, getParent()
						.getSize().height - 80);
				btnExit.setBounds(getParent().getSize().width - 110,
						getParent().getSize().height - 65, 89, 23);
				btnAddNews.setBounds(10, getParent().getSize().height - 65,
						158, 23);
			}
		});

		addInternalFrameListener(new InternalFrameAdapter() {
			@Override
			public void internalFrameOpened(InternalFrameEvent arg0) {
				DisplayTable();
			}
		});
		setTitle("List of News");
		setBounds(100, 100, 723, 443);
		getContentPane().setLayout(null);

		getContentPane().add(btnExit);

		getContentPane().add(btnAddNews);

		tblNews = new JTable();
		tblNews.setRowMargin(15);
		tblNews.setPreferredScrollableViewportSize(new Dimension(100, 100));

		tblNews.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {

				if (arg0.getClickCount() == 2) {
					DefaultTableModel model = (DefaultTableModel) tblNews
							.getModel();

					idNews = (int) model.getValueAt(tblNews.getSelectedRow(), 0);
					DescriptionNews = (String) model.getValueAt(
							tblNews.getSelectedRow(), 2);
					iconNews = (ImageIcon) model.getValueAt(
							tblNews.getSelectedRow(), 1);
					typeNews = (String) model.getValueAt(tblNews.getSelectedRow(), 3);
					UpdateNews updateNews = new UpdateNews();
					updateNews.setVisible(true);
				}
			}
		});
		tblNews.setModel(new DefaultTableModel(new Object[][] {}, new String[] {
				"Id", "Description", "Path", "Type" }) {
			private static final long serialVersionUID = 5403468916125701088L;
			boolean[] columnEditables = new boolean[] { false, false, false,
					false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});

		tblNews.setBounds(10, 11, 687, 353);

		getContentPane().add(tblNews);

	}

	public static void DisplayTable() {
		tblNews.getColumnModel().getColumn(1)
				.setCellRenderer(new ImageRenderer());
		DefaultTableModel model = (DefaultTableModel) tblNews.getModel();

		tblNews.getColumnModel().getColumn(0).setMinWidth(0);
		tblNews.getColumnModel().getColumn(0).setMaxWidth(0);
		tblNews.getColumnModel().getColumn(0).setWidth(0);
		tblNews.setRowHeight(120);
		List<MultimediaItem> listemultimediaItems = new ArrayList<MultimediaItem>();
		listemultimediaItems = MultimediaItemDelegate.findAll();
		int ss = 0;
		for (MultimediaItem multimediaItem : listemultimediaItems) {
			ImageIcon icon = new ImageIcon("src/com/votePlateform/files/"
					+ multimediaItem.getPath());
			Image img = icon.getImage();
			Image newimg = img.getScaledInstance(150, 120,
					java.awt.Image.SCALE_SMOOTH);
			ImageIcon newIcon = new ImageIcon(newimg);
			model.addRow(new Object[] { multimediaItem.getIdItem(),
					new ImageIcon(), multimediaItem.getDescriptionOfItem(),
					multimediaItem.getTypeOfItem() });
			tblNews.setValueAt(newIcon, ss, 1);
			ss++;
		}
	}

	public static void refreshTable() {
		DefaultTableModel dm = (DefaultTableModel) tblNews.getModel();
		dm.getDataVector().removeAllElements();
		DisplayTable();
	}

}

class ImageRenderer extends DefaultTableCellRenderer {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3884727805151462020L;
	JLabel lbl = new JLabel();

	public Component getTableCellRendererComponent(JTable table, Object value,
			boolean isSelected, boolean hasFocus, int row, int column) {
		lbl.setIcon((ImageIcon) value);
		return lbl;
	}
}