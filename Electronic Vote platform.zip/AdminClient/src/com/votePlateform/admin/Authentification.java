package com.votePlateform.admin;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import com.votePlateform.delegate.AuthAdminDelegate;
import com.votePlateform.domain.IsieAdmin;

import de.javasoft.plaf.synthetica.SyntheticaClassyLookAndFeel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.ParseException;
import javax.swing.JPasswordField;

public class Authentification extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8760838697971799702L;
	private JPanel contentPane;
	private static JTextField txtLogin;
	private JPasswordField txtPasswd;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 * 
	 * @throws ParseException
	 * @throws UnsupportedLookAndFeelException
	 */
	public Authentification() {

		setTitle("Authentification");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 438, 177);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblLogin = new JLabel("Login");
		lblLogin.setBounds(54, 22, 68, 17);
		contentPane.add(lblLogin);

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(54, 62, 68, 17);
		contentPane.add(lblPassword);

		txtLogin = new JTextField();
		txtLogin.setBounds(132, 22, 115, 20);
		contentPane.add(txtLogin);
		txtLogin.setColumns(10);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancel.setBounds(323, 92, 89, 23);
		contentPane.add(btnCancel);

		JButton btnConnect = new JButton("Connect");
		btnConnect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String passText = new String(txtPasswd.getPassword());
				IsieAdmin myAdmin = AuthAdminDelegate.authentication(
						txtLogin.getText(), passText);

				if (myAdmin != null) {
					MDIparent mdi;
					try {
						mdi = new MDIparent();
						mdi.setVisible(true);
						dispose();
					} catch (UnsupportedLookAndFeelException | ParseException e1) {
						e1.printStackTrace();
					}
				} else {
					JOptionPane.showMessageDialog(null,
							"Login or password incorrect");
					txtPasswd.setText("");
				}

			}
		});
		btnConnect.setBounds(224, 92, 89, 23);
		contentPane.add(btnConnect);

		txtPasswd = new JPasswordField();
		txtPasswd.setBounds(132, 60, 115, 20);
		contentPane.add(txtPasswd);

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((dim.width / 2) - (this.getSize().width / 2),
				(dim.height / 2) - (this.getSize().height / 2));
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Authentification frame = new Authentification();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		});
	}
}
