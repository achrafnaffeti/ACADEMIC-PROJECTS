package com.votePlateform.admin;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.votePlateform.delegate.MultimediaItemDelegate;
import com.votePlateform.delegate.PartyDelegate;
import com.votePlateform.domain.Citizen;
import com.votePlateform.domain.MultimediaItem;
import com.votePlateform.domain.Party;

import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JLabel;

public class ListParty extends JInternalFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4180418309824464664L;
	private static JTable tblParty;
	private JTextField txtSearchByName;
	private static java.util.List<Party> listParty;
	public static int idParty;
	public static List<Citizen> lstCitizen;
	public static List<MultimediaItem> lstMultimedia;
	private JLabel lblRecherche;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListParty frame = new ListParty();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ListParty() {
		listParty = new ArrayList<Party>();
		lstMultimedia = new ArrayList<MultimediaItem>();
		final JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnExit.setBounds(517, 383, 89, 23);
		getContentPane().add(btnExit);
		txtSearchByName = new JTextField();
		txtSearchByName.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (txtSearchByName.getText().isEmpty()) {
					refreshTable();
					lblRecherche.setText("");
				} else {
					DefaultTableModel dm = (DefaultTableModel) tblParty
							.getModel();
					dm.getDataVector().removeAllElements();
					List<Party> lst = PartyDelegate
							.searchByName(txtSearchByName.getText());
					if (lst.isEmpty()) {
						lblRecherche.setText("no Citizen name '"
								+ txtSearchByName.getText() + "'");
					} else {
						String[] columnNames = { "id", "Founding member",
								"Description of party",
								"Political affilliation", "list of citizen",
								"multimedia" };
						dm.addRow(columnNames);
						for (Party party : lst) {
							dm.addRow(new Object[] { party.getIdCondidat(),
									party.getFoundingMember(), party.getDescriptionOfParty(),
									party.getPoliticalAffiliation(), party.getListOfCitizen(),
									MultimediaItemDelegate.findByParty(party.getIdCondidat()) });
						}
						lblRecherche.setText("");
					}
				}
			}
		});
		txtSearchByName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		txtSearchByName.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent arg0) {
				txtSearchByName.setText("");
			}

			@Override
			public void focusLost(FocusEvent e) {
				txtSearchByName.setText("Search by name ...");
			}
		});
		txtSearchByName.setForeground(Color.GRAY);
		txtSearchByName.setText("Search by name ...");

		getContentPane().add(txtSearchByName);
		txtSearchByName.setColumns(10);
		txtSearchByName.setBounds(491, 11, 115, 25);
		tblParty = new JTable();
		tblParty.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (arg0.getClickCount() == 2 && tblParty.getSelectedRow() != 0) {
					DefaultTableModel model = (DefaultTableModel) tblParty
							.getModel();
					idParty = (int) model.getValueAt(tblParty.getSelectedRow(),
							0);
					lstCitizen = (List<Citizen>) model.getValueAt(
							tblParty.getSelectedRow(), 4);
					lstMultimedia = (List<MultimediaItem>) model.getValueAt(
							tblParty.getSelectedRow(), 5);

					DetailOfParty d = new DetailOfParty();
					d.setVisible(true);
				}
			}
		});
		tblParty.setBounds(10, 42, 596, 330);

		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent arg0) {
				tblParty.setSize(getParent().getSize().width - 30, getParent()
						.getSize().height - 110);
				btnExit.setBounds(getParent().getSize().width - 110,
						getParent().getSize().height - 60, 89, 23);
				txtSearchByName.setBounds(getParent().getSize().width - 135,
						15, 115, 25);
			}
		});
		getContentPane().setLayout(null);

		getContentPane().add(tblParty);

		setTitle("List of Party");
		setBounds(100, 100, 632, 447);

		tblParty.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "id", "Founding member", "Description of party",
						"Political affilliation", "citizen", "mumtimedia" }) {
			private static final long serialVersionUID = 5403468916125701088L;
			boolean[] columnEditables = new boolean[] { false, false, false,
					false, false, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});

		lblRecherche = new JLabel("");
		lblRecherche.setForeground(Color.RED);
		lblRecherche.setBounds(336, 16, 145, 14);
		getContentPane().add(lblRecherche);
		DisplayTable();
	}

	public static void DisplayTable() {
		listParty = PartyDelegate.findAll();
		DefaultTableModel model = (DefaultTableModel) tblParty.getModel();
		String[] columnNames = { "id", "Founding member",
				"Description of party", "Political affilliation",
				"list of citizen", "multimedia" };

		model.addRow(columnNames);
		tblParty.getColumnModel().getColumn(0).setMinWidth(0);
		tblParty.getColumnModel().getColumn(0).setMaxWidth(0);
		tblParty.getColumnModel().getColumn(0).setWidth(0);

		tblParty.getColumnModel().getColumn(4).setMinWidth(0);
		tblParty.getColumnModel().getColumn(4).setMaxWidth(0);
		tblParty.getColumnModel().getColumn(4).setWidth(0);

		tblParty.getColumnModel().getColumn(5).setMinWidth(0);
		tblParty.getColumnModel().getColumn(5).setMaxWidth(0);
		tblParty.getColumnModel().getColumn(5).setWidth(0);

		for (Party party : listParty) {
			model.addRow(new Object[] { party.getIdCondidat(),
					party.getFoundingMember(), party.getDescriptionOfParty(),
					party.getPoliticalAffiliation(), party.getListOfCitizen(),
					MultimediaItemDelegate.findByParty(party.getIdCondidat()) });
		}

	}

	public static void refreshTable() {
		DefaultTableModel dm = (DefaultTableModel) tblParty.getModel();
		dm.getDataVector().removeAllElements();
		DisplayTable();
	}

}
