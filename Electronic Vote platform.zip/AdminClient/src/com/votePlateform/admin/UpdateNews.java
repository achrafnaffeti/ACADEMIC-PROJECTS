package com.votePlateform.admin;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import com.votePlateform.domain.MultimediaItem;
import com.votePlateform.delegate.MultimediaItemDelegate;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class UpdateNews extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8174127452315483932L;
	private final JPanel contentPanel = new JPanel();
	private JTextField txtDescription;
	private JLabel lblImage;
	private JLabel lblTypeNews;
	private File fileToSave;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UpdateNews dialog = new UpdateNews();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public UpdateNews() {
		setModal(true);
		setResizable(false);
		setTitle("Update news");
		setBounds(100, 100, 402, 238);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		txtDescription = new JTextField();
		txtDescription.setBounds(201, 43, 169, 49);
		contentPanel.add(txtDescription);
		txtDescription.setColumns(10);

		JLabel lblDescription = new JLabel("Description");

		contentPanel.add(lblDescription);

		JButton btnUpload = new JButton("Upload File");
		btnUpload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Chooser frame = new Chooser();
				fileToSave = frame.GetFileToSave();
			}
		});
		btnUpload.setBounds(259, 115, 111, 23);
		contentPanel.add(btnUpload);

		JLabel lblType = new JLabel("Type :");
		lblType.setBounds(10, 11, 46, 14);
		contentPanel.add(lblType);

		lblTypeNews = new JLabel("New label");
		lblTypeNews.setBounds(51, 11, 78, 14);
		contentPanel.add(lblTypeNews);

		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						MultimediaItem m = MultimediaItemDelegate
								.findById(ListNews.idNews);
						m.setDescriptionOfItem(txtDescription.getText()
								.toString());
						if (!fileToSave.getName().equals("")) {
							Path pathDelete = Paths
									.get("src/com/votePlateform/files/"
											+ m.getPath());
							try {
								Files.delete(pathDelete);
							} catch (IOException e2) {
								e2.printStackTrace();
							}
							File f = new File("src/com/votePlateform/files/"
									+ fileToSave.getName());
							Path FROM = Paths.get(fileToSave.getPath());
							Path TO = Paths.get(f.getPath());
							// overwrite existing file, if exists
							CopyOption[] options = new CopyOption[] {
									StandardCopyOption.REPLACE_EXISTING,
									StandardCopyOption.COPY_ATTRIBUTES };
							try {
								Files.copy(FROM, TO, options);
							} catch (IOException e1) {
								e1.printStackTrace();
							}
							m.setPath(fileToSave.getName());
						}

						MultimediaItemDelegate.updateMultimedia(m);
						ListNews.refreshTable();
						dispose();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
				{
					JButton cancelButton = new JButton("Cancel");
					cancelButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							dispose();
						}
					});

					JButton btnNewButton = new JButton("Delete");
					btnNewButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							MultimediaItem m = MultimediaItemDelegate
									.findById(ListNews.idNews);
							MultimediaItemDelegate.deleteMultimedia(m);
							ListNews.refreshTable();
							dispose();
						}
					});
					buttonPane.add(btnNewButton);
					cancelButton.setActionCommand("Cancel");
					buttonPane.add(cancelButton);
				}
			}
		}

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((dim.width / 2) - (this.getSize().width / 2),
				(dim.height / 2) - (this.getSize().height / 2));
		initialize();

	}

	private void initialize() {
		txtDescription.setText(ListNews.DescriptionNews);
		lblImage = new JLabel(ListNews.iconNews);
		lblImage.setBounds(20, 43, 160, 130);
		contentPanel.add(lblImage);
		lblTypeNews.setText(ListNews.typeNews);
	}
}
