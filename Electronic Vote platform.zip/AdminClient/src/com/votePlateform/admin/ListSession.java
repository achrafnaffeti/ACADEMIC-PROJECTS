package com.votePlateform.admin;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JInternalFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;
import javax.swing.JButton;

import com.votePlateform.delegate.SessionDelegate;
import com.votePlateform.domain.Session;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Date;

public class ListSession extends JInternalFrame {
	/**
	 * 
	 */

	public static String SessionDescription;
	public static Date SessiondateOp;
	public static Date SessionDateEn;
	public static int IdSelected;
	private static final long serialVersionUID = -6043119632143509744L;
	private static JTable tblSession;

	private static java.util.List<Session> myList;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListSession frame = new ListSession();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ListSession() {
		myList = new ArrayList<Session>();
		final JButton btnExit = new JButton("Exit");
		btnExit.setBounds(608, 375, 89, 23);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});

		final JButton btnAddSession = new JButton("Add new session");
		btnAddSession.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AddSession newSession = new AddSession();
				Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
				newSession.setLocation(dim.width / 2
						- newSession.getSize().width / 2, dim.height / 2
						- newSession.getSize().height / 2);
				newSession.setVisible(true);
			}
		});
		btnAddSession.setBounds(10, 375, 158, 23);

		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent arg0) {
				tblSession.setSize(getParent().getSize().width, getParent()
						.getSize().height - 80);
				btnExit.setBounds(getParent().getSize().width - 110,
						getParent().getSize().height - 65, 89, 23);
				btnAddSession.setBounds(10, getParent().getSize().height - 65,
						158, 23);
			}
		});

		addInternalFrameListener(new InternalFrameAdapter() {
			@Override
			public void internalFrameOpened(InternalFrameEvent arg0) {
				DisplayTable();
			}
		});
		setTitle("List of Session");
		setBounds(100, 100, 723, 443);
		getContentPane().setLayout(null);

		getContentPane().add(btnExit);

		getContentPane().add(btnAddSession);

		tblSession = new JTable();

		tblSession.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent arg0) {
				if (arg0.getClickCount() == 2
						&& tblSession.getSelectedRow() != 0) {
					DefaultTableModel model = (DefaultTableModel) tblSession
							.getModel();
					IdSelected = (int) model.getValueAt(
							tblSession.getSelectedRow(), 3);
					SessiondateOp = (Date) model.getValueAt(
							tblSession.getSelectedRow(), 0);
					SessionDateEn = (Date) model.getValueAt(
							tblSession.getSelectedRow(), 1);
					SessionDescription = (String) model.getValueAt(
							tblSession.getSelectedRow(), 2);
					UpdateSession updateSession = new UpdateSession();
					updateSession.setVisible(true);
				}
			}
		});
		tblSession.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "Opnening date", "Ending date", "Description",
						"id" }) {
			private static final long serialVersionUID = 5403468916125701088L;
			boolean[] columnEditables = new boolean[] { false, false, false,
					false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});

		tblSession.setBounds(10, 11, 687, 353);
		getContentPane().add(tblSession);

	}

	public static void DisplayTable() {
		myList = SessionDelegate.findAll();
		DefaultTableModel model = (DefaultTableModel) tblSession.getModel();
		String[] columnNames = { "Opnening date", "Ending date", "Description",
				"id" };
		model.addRow(columnNames);
		tblSession.getColumnModel().getColumn(3).setMinWidth(0);
		tblSession.getColumnModel().getColumn(3).setMaxWidth(0);
		tblSession.getColumnModel().getColumn(3).setWidth(0);

		for (Session session : myList) {
			model.addRow(new Object[] { session.getOpeningDateOfSession(),
					session.getEndingDateOfSession(),
					session.getDescriptionOfSession(), session.getIdSession() });
		}

	}

	public static void refreshTable() {
		DefaultTableModel dm = (DefaultTableModel) tblSession.getModel();
		dm.getDataVector().removeAllElements();
		DisplayTable();
	}
}
