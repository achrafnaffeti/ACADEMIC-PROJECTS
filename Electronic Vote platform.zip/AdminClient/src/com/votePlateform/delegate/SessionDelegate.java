package com.votePlateform.delegate;

import java.util.List;

import com.votePlateform.domain.Session;
import com.votePlateform.locator.ServiceLocator;
import com.votePlateform.sevices.ManageSessionEJBRemote;

public class SessionDelegate {
	private static ManageSessionEJBRemote session;

	private static ManageSessionEJBRemote getRemote() {
		session = (ManageSessionEJBRemote) ServiceLocator
				.getInstance()
				.getProxy(
						"/ElectronicVotePlateform/ManageSessionEJB!com.votePlateform.sevices.ManageSessionEJBRemote");

		return session;
	}

	public static void addSession(Session session) {
		getRemote().addSession(session);
	}

	public static void updateSession(Session session) {
		getRemote().updateSession(session);
	}

	public static void deleteSession(int id) {
		getRemote().deleteSession(id);
	}

	public static Session findById(int id) {
		return getRemote().findById(id);
	}

	public static List<Session> findAll() {
		return getRemote().findAll();
	}
}
