package com.votePlateform.delegate;

import java.util.List;
import com.votePlateform.domain.MultimediaItem;
import com.votePlateform.locator.ServiceLocator;
import com.votePlateform.sevices.MultimediaItemEJBRemote;

public class MultimediaItemDelegate {

	private static MultimediaItemEJBRemote getRemote() {
		MultimediaItemEJBRemote CART = (MultimediaItemEJBRemote) ServiceLocator
				.getInstance()
				.getProxy(
						"/ElectronicVotePlateform/MultimediaItemEJB!com.votePlateform.sevices.MultimediaItemEJBRemote");
		return CART;
	}

	public static void addMultimedia(MultimediaItem m) {
		getRemote().addMultimediaItem(m);
	}

	public static void updateMultimedia(MultimediaItem m) {
		getRemote().updateMultimediaItem(m);
	}

	public static void deleteMultimedia(MultimediaItem m) {
		getRemote().deleteMultimediaItem(m);
	}

	public static MultimediaItem findById(int id) {
		return getRemote().findById(id);
	}

	public static List<MultimediaItem> findAll() {
		return getRemote().findAll();
	}
	
	public static List<MultimediaItem> findByParty(int id) {
		return getRemote().findByParty(id);
	}
}
