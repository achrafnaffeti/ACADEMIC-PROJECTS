package com.votePlateform.delegate;

import java.util.List;
import com.votePlateform.domain.Party;
import com.votePlateform.locator.ServiceLocator;
import com.votePlateform.sevices.PartyEJBRemote;

public class PartyDelegate {
	private static PartyEJBRemote party;

	private static PartyEJBRemote getRemote() {
		party = (PartyEJBRemote) ServiceLocator
				.getInstance()
				.getProxy(
						"/ElectronicVotePlateform/PartyEJB!com.votePlateform.sevices.PartyEJBRemote");

		return party;
	}
	public static void deleteParty(int id) {
		getRemote().deleteParty(id);
	}

	public static Party findById(int id) {
		return getRemote().findById(id);
	}

	public static List<Party> findAll() {
		return getRemote().findAll();
	}
	
	public static List<Party> searchByName(String name) {
		return getRemote().searchByname(name);
	}
	
}
