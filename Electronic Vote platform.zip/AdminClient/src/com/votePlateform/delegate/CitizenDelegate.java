package com.votePlateform.delegate;

import java.util.List;

import com.votePlateform.locator.ServiceLocator;
import com.votePlateform.sevices.CitizenEJBRemote;
import com.votePlateform.domain.Citizen;

public class CitizenDelegate {

	private static CitizenEJBRemote cart; // Il ont �t� d�clar�s static car

	private static CitizenEJBRemote getRemoteEJB() { // ils vont �tre appel�
														// par une m�thode
														// statique
		cart = (CitizenEJBRemote) ServiceLocator
				.getInstance()
				.getProxy(
						"/ElectronicVotePlateform/CitizenEJB!com.votePlateform.sevices.CitizenEJBRemote");
		return cart;
	}

	public static void addFreelancer(Citizen citizen) {
		getRemoteEJB().AddCitizen(citizen);
	}

	public static List<Citizen> SearchCitizen(int cin) {
		return getRemoteEJB().SearchCitizen(cin);
	}

	public static List<Citizen> DisplayAllCitizen() {
		return getRemoteEJB().DisplayAllCitizen();
	}

	public static void Modifycitizen(Citizen ci, int cin) {
		getRemoteEJB().UpdateCitizen(ci, cin);
	}

	public static void Deletecitizen(int cin) {
		getRemoteEJB().DeleteCitizen(cin);
	}
	public static List<Citizen> findByName(String name) {
		return getRemoteEJB().searchByName(name);
	}

}
