package com.votePlateform.delegate;

import java.util.List;

import com.votePlateform.domain.IsieAdmin;
import com.votePlateform.locator.ServiceLocator;
import com.votePlateform.sevices.AuthAdminIsieRemote;

public class AuthAdminDelegate {

	private static AuthAdminIsieRemote GetadminIsieRemote() {

		AuthAdminIsieRemote remote = (AuthAdminIsieRemote) ServiceLocator
				.getInstance()
				.getProxy(
						"/ElectronicVotePlateform/AuthAdminIsie!com.votePlateform.sevices.AuthAdminIsieRemote");
		return remote;

	}

	public static IsieAdmin authentication(String login, String password) {
		return GetadminIsieRemote().authentication(login, password);
	}

	public static void UpdateAdmin(IsieAdmin i) {
		GetadminIsieRemote().updateAdmin(i);
	}

	public static List<IsieAdmin> findAll() {
		return GetadminIsieRemote().findAll();
	}
	
	public static IsieAdmin serachAdminById(int id) {
		return GetadminIsieRemote().serachAdminById(id);
	}
	
	public static void removeAdminIsie(IsieAdmin i) {
		GetadminIsieRemote().removeAdminIsie(i);
	}

}
